
package servidor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.math.BigInteger;
import java.security.spec.RSAPublicKeySpec;
import java.security.KeyFactory;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;



public class ClienteConectado implements Runnable{
    
    Socket socket;
    String nombreUsuario;
    Thread hiloGetMensaje;
    BufferedReader in;
    PrintWriter out;
    RSAPublicKey publicKey;
    Boolean tieneAES = new Boolean(false);
    Boolean estado = new Boolean(false);
    
     public ClienteConectado(Socket socket, String usuario) {
        configurarCliente(socket);
        this.nombreUsuario = usuario;
    }
     public void configurarCliente(Socket socket){
         this.socket = socket;
         
         try{
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream());

            hiloGetMensaje = new Thread(this);
            hiloGetMensaje.start();
        }catch (Exception e) {
            e.printStackTrace();
        }
     }
     
     public boolean comprobar() throws IOException{
         
         return estado;
         
     }
     
     public void desconectar() throws IOException{
         in.close();
         out.close();
         socket.close();
         
     }
     
     public String getNom(){
         return nombreUsuario;
     }
     
     
     /*Este metodo RECONSTRUYE la clave a partir del modulo y exp pasado*/
     public void crearpublica(String modulo, String exponente) throws InvalidKeySpecException{ 
         
         try{
              
            BigInteger clave = new BigInteger(modulo,16); // hex base
            BigInteger claveexponente = new BigInteger(exponente,10); // decimal base

            RSAPublicKeySpec keySpeck = new RSAPublicKeySpec(clave, claveexponente);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            publicKey = (RSAPublicKey) keyFactory.generatePublic(keySpeck);
            //System.out.println("La clave se ha reconstruido correctamente");
         } catch (NoSuchAlgorithmException ex) {
            System.out.println("AY CARAMBA DIJO VAR SINSON");
        }
         
     }
      public void getMensajes() throws IOException {
        try{
            String mensaje;
            while ((mensaje = in.readLine()) != null) {
                
                if(mensaje.compareTo("me6166_d")==0){
                   estado = true;
               }
                
                for (ClienteConectado cliente : ServidorMultiUsuario.clientes) {
                    cliente.enviarMensaje(mensaje);
                }
            }
        }catch (Exception e) {
            socket.close();
            estado = true;
        }
    }
      
      public RSAPublicKey getPublica(){
          return(publicKey);
      }
      
      public void enviarMensaje(String mensaje) {
        out.println(mensaje);
        out.flush();
    }
      @Override 
    public void run() {
        try {
            getMensajes();
        } catch (IOException ex) {
            Logger.getLogger(ClienteConectado.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
